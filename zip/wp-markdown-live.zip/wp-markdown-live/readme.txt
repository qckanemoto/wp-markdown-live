=== wp-markdown-live ===
Contributors: Takashi Kanemoto
Donate link: none
Tags: markdown, live, realtime, preview
Requires at least: 3.0
Tested up to: 3.6
Stable tag: 1.0.1
License: MIT
License URI: http://opensource.org/licenses/mit-license.php

This plugin hide wysiwyg editor and create Markdown editor with live preview.

== Description ==

This plugin hide wysiwyg editor and create Markdown editor with live preview.

== Installation ==

1. Upload the entire `wp-markdown-live` folder to the `/wp-content/plugins/` directory.
2. Activate the plugin through the 'Plugins' menu in WordPress.

== Frequently Asked Questions ==

none.

== Screenshots ==

1. Markdown editor and live-preview.

== Changelog ==

= 1.0.1 =
* Initial release.

== Upgrade Notice ==

none.
